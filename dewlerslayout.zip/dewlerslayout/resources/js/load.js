window.onload = function(){
    var contenedor = document.getElementById('load-container');

    setTimeout(function(){
        contenedor.style.visibility = "hidden";
        contenedor.style.opacity = '0';
    },500)
};

